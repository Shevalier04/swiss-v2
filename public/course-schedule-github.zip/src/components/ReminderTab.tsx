import React, { useState, useEffect } from 'react';
import { Course, RemindSettings } from '../types';
import { SLOTS, toMinutes, isCourseInWeek, getWeekNo, getNextDayInfo } from '../utils/time';
import {
  Bell,
  Volume2,
  ShieldCheck,
  Play,
  Moon,
  Calendar,
  Sparkles,
  Radio,
  Smartphone,
  CheckCircle,
  RefreshCw,
  AlertTriangle,
  Globe,
} from 'lucide-react';
import { NotificationGuideModal } from './NotificationGuideModal';
import {
  detectNotificationCapability,
  NotificationCapability,
  isPushNotificationSupported,
  getCurrentPushSubscription,
  subscribeToPushNotifications,
  unsubscribeFromPushNotifications,
  sendServerTestPush,
  fetchServerPushStatus,
  requestLocalSystemPermission,
  sendLocalTestNotification,
} from '../utils/pushManager';

interface ReminderTabProps {
  settings: RemindSettings;
  onUpdateSettings: (newSettings: Partial<RemindSettings>) => void;
  courses: Course[];
  onTriggerTestReminder: () => void;
  onTriggerSundayTestReminder?: () => void;
  onOpenDoctor?: () => void;
  toast: (msg: string) => void;
}

export const ReminderTab: React.FC<ReminderTabProps> = ({
  settings,
  onUpdateSettings,
  courses,
  onTriggerTestReminder,
  onTriggerSundayTestReminder,
  onOpenDoctor,
  toast,
}) => {
  const [capability, setCapability] = useState<NotificationCapability>(() => detectNotificationCapability());
  const [showHuaweiGuide, setShowHuaweiGuide] = useState(false);
  const [showUnblockGuide, setShowUnblockGuide] = useState(false);
  const [localSysPermission, setLocalSysPermission] = useState<NotificationPermission | 'unsupported'>(() => {
    return typeof Notification !== 'undefined' ? Notification.permission : 'unsupported';
  });

  const [isPushSupported, setIsPushSupported] = useState(false);
  const [isPushSubscribed, setIsPushSubscribed] = useState(false);
  const [pushLoading, setPushLoading] = useState(false);
  const [testingPush, setTestingPush] = useState(false);
  const [serverDeviceCount, setServerDeviceCount] = useState<number>(0);

  useEffect(() => {
    const cap = detectNotificationCapability();
    setCapability(cap);
    setIsPushSupported(cap.hasPushManager);

    if (cap.hasPushManager) {
      getCurrentPushSubscription().then(sub => {
        setIsPushSubscribed(!!sub);
      });
      fetchServerPushStatus().then(status => {
        setServerDeviceCount(status.subscriptionCount);
        if (status.hasSubscriptions) {
          setIsPushSubscribed(true);
        }
      });
    }
  }, []);

  const handlePermissionRecovered = async () => {
    onUpdateSettings({ inapp: true, sound: true, enabled: true });
    if (typeof Notification !== 'undefined') {
      setLocalSysPermission(Notification.permission);
      if (Notification.permission === 'granted') {
        onUpdateSettings({ sys: true });
      }
    }
    const cap = detectNotificationCapability();
    setCapability(cap);

    if (cap.hasPushManager) {
      try {
        const res = await subscribeToPushNotifications();
        if (res.success) {
          setIsPushSubscribed(true);
          onUpdateSettings({ webPushEnabled: true });
          const st = await fetchServerPushStatus();
          setServerDeviceCount(st.subscriptionCount);
        }
      } catch {}
    }
  };

  const handleTogglePush = async () => {
    if (pushLoading) return;

    if (!isPushSubscribed) {
      if (typeof Notification !== 'undefined' && Notification.permission === 'denied') {
        setShowUnblockGuide(true);
        return;
      }
    }

    setPushLoading(true);

    try {
      if (isPushSubscribed) {
        const res = await unsubscribeFromPushNotifications();
        if (res.success) {
          setIsPushSubscribed(false);
          onUpdateSettings({ webPushEnabled: false });
          toast(res.message);
          const st = await fetchServerPushStatus();
          setServerDeviceCount(st.subscriptionCount);
        } else {
          toast(res.message);
        }
      } else {
        const res = await subscribeToPushNotifications();
        if (res.success) {
          setIsPushSubscribed(true);
          onUpdateSettings({ webPushEnabled: true, sys: true });
          toast(res.message);
          const st = await fetchServerPushStatus();
          setServerDeviceCount(st.subscriptionCount);
        } else {
          toast(res.message);
          if (res.isBlocked || (typeof Notification !== 'undefined' && Notification.permission === 'denied')) {
            setShowUnblockGuide(true);
          }
        }
      }
    } catch (err: any) {
      toast(err.message || '操作失败');
    } finally {
      setPushLoading(false);
    }
  };

  const handleTestServerPush = async () => {
    if (testingPush) return;
    if (typeof Notification !== 'undefined' && Notification.permission === 'denied') {
      setShowUnblockGuide(true);
      return;
    }
    setTestingPush(true);
    toast('正在发送系统级 Web Push 测试推送，请立即熄屏或切到后台查看...');

    try {
      const res = await sendServerTestPush();
      toast(res.message);
    } catch (err: any) {
      toast(err.message || '测试推送请求失败');
    } finally {
      setTestingPush(false);
    }
  };

  const handleCopyUrlForNativeBrowser = () => {
    if (typeof window === 'undefined') return;
    const url = window.location.href;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard
        .writeText(url)
        .then(() => {
          toast('课表网址已成功复制！请打开手机自带浏览器（如华为/小米/Chrome）粘贴访问即可开启系统锁屏推送。');
        })
        .catch(() => {
          prompt('请复制当前课表网址并在手机自带浏览器打开：', url);
        });
    } else {
      prompt('请复制当前课表网址并在手机自带浏览器打开：', url);
    }
  };

  const handleRequestLocalPermission = async () => {
    if (capability.isQuark || !capability.hasNotification) {
      onUpdateSettings({ inapp: true, sound: true, enabled: true });
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try { navigator.vibrate([250, 100, 250]); } catch {}
      }
      toast('夸克提醒模式已开启！已同步激活页面悬浮横幅、手机物理震动与蜂鸣提示音。');
      return;
    }

    if (typeof Notification !== 'undefined' && Notification.permission === 'denied') {
      setShowUnblockGuide(true);
      return;
    }

    const res = await requestLocalSystemPermission();
    setLocalSysPermission(res.status);
    if (res.granted) {
      if (res.isQuarkFallback) {
        onUpdateSettings({ inapp: true, sound: true, enabled: true });
      } else {
        onUpdateSettings({ sys: true });
      }
      toast(res.message);
    } else {
      toast(res.message);
      if (res.isBlocked || res.status === 'denied') {
        setShowUnblockGuide(true);
      }
    }
  };

  const handleTestLocalNotification = async () => {
    if (capability.isQuark || !capability.hasNotification) {
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try { navigator.vibrate([250, 100, 250]); } catch {}
      }
      onTriggerTestReminder();
      toast('【夸克测试成功】手机已触发物理震动！上课前页面横幅与蜂鸣将准时生效。');
      return;
    }

    if (typeof Notification !== 'undefined' && Notification.permission === 'denied') {
      setShowUnblockGuide(true);
      return;
    }
    const res = await sendLocalTestNotification();
    toast(res.message);
  };

  const now = new Date();
  const currentWeek = Math.max(1, Math.min(25, getWeekNo(now)));
  const todayDayIdx = (now.getDay() + 6) % 7;
  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  const nextCourse = courses
    .filter(c => c.day === todayDayIdx && isCourseInWeek(currentWeek, c.weeks))
    .sort((a, b) => a.s - b.s)
    .find(c => toMinutes(SLOTS[c.s].s) > currentMinutes);

  // Check tomorrow's morning course
  const nextDay = getNextDayInfo(now);
  const tomorrowCourses = courses
    .filter(c => c.day === nextDay.dayIdx && isCourseInWeek(nextDay.weekNo, c.weeks))
    .sort((a, b) => a.s - b.s);
  const tomorrowFirstCourse = tomorrowCourses[0];

  const notificationPermission =
    typeof Notification !== 'undefined' ? Notification.permission : 'unsupported';

  const requestSysPermission = async () => {
    if (capability.isQuark || typeof Notification === 'undefined' || !capability.hasNotification) {
      onUpdateSettings({ inapp: true, sound: true, enabled: true });
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try { navigator.vibrate([200, 100, 200]); } catch {}
      }
      toast('夸克浏览器内核精简了系统通知，已为您自动激活【应用内悬浮横幅 + 手机物理震动 + 提示音】！');
      return;
    }
    if (Notification.permission === 'denied') {
      setShowUnblockGuide(true);
      return;
    }
    try {
      const res = await Notification.requestPermission();
      if (res === 'granted') {
        onUpdateSettings({ sys: true });
        setLocalSysPermission('granted');
        toast('系统通知权限已开启');
      } else {
        setLocalSysPermission(res);
        if (res === 'denied') {
          setShowUnblockGuide(true);
        } else {
          toast('未开启通知权限，请在浏览器地址栏或手机设置中允许');
        }
      }
    } catch (e) {
      toast('通知权限请求失败');
    }
  };

  return (
    <div className="space-y-4 pb-6 select-none">
      {/* Title */}
      <div className="border-b-[2.5px] border-[#e9e4d8] pb-2 flex items-end justify-between">
        <div>
          <div className="font-editorial text-2xl sm:text-3xl font-extrabold tracking-wide text-[#e9e4d8]">
            上课提醒
          </div>
          <div className="text-[9.5px] font-mono tracking-[3px] text-[#8f8b80] mt-0.5">
            CLASS REMINDER NOTIFICATIONS
          </div>
        </div>
        {onOpenDoctor && (
          <button
            type="button"
            onClick={onOpenDoctor}
            className="px-2.5 py-1 rounded bg-[#6b7cff]/15 hover:bg-[#6b7cff]/25 border border-[#6b7cff]/40 text-[#8ea4ff] font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>浏览器能力诊断</span>
          </button>
        )}
      </div>

      {/* Status Pad */}
      <div className="bg-[#26282e] border-2 border-[#33363d] p-4 text-xs leading-relaxed space-y-1.5 rounded">
        <div>
          即时提醒：
          <b className={settings.enabled ? 'text-[#6b7cff]' : 'text-[#8f8b80]'}>
            {settings.enabled ? '已启用 ✓' : '已关闭 ✕'}
          </b>
          {' ｜ '}课前 <b className="text-[#6b7cff]">{settings.lead}</b> 分钟提醒
        </div>
        <div>
          周日晚提醒：
          <b className={settings.sundayEveEnabled ? 'text-[#4ade80]' : 'text-[#8f8b80]'}>
            {settings.sundayEveEnabled ? `已开启 (${settings.sundayEveHour || 20}:00 推送明日早课)` : '已关闭'}
          </b>
          {' ｜ '}课表提前更新：
          <b className={settings.sundayAutoAdvance ? 'text-[#6b7cff]' : 'text-[#8f8b80]'}>
            {settings.sundayAutoAdvance ? '周日晚自动切换下周 ✓' : '手动切换'}
          </b>
        </div>
        <div>
          系统通知权限：
          {capability.isQuark || !capability.hasNotification ? (
            <b className="text-[#4ade80]">夸克应用内横幅 + 手机物理震动已激活 ✓</b>
          ) : (
            <>
              <b className={notificationPermission === 'granted' ? 'text-[#4ade80]' : 'text-[#ff6b57]'}>
                {notificationPermission === 'granted'
                  ? '已授权 ✓'
                  : notificationPermission === 'denied'
                  ? '已被浏览器拒绝/拦截'
                  : '未授权'}
              </b>
              {notificationPermission === 'denied' && (
                <button
                  type="button"
                  onClick={() => setShowUnblockGuide(true)}
                  className="ml-2 px-1.5 py-0.5 rounded bg-[#ff6b57]/20 border border-[#ff6b57]/40 text-[#ff8f80] hover:text-white text-[10.5px] font-bold cursor-pointer inline-flex items-center gap-1 transition-colors"
                >
                  <AlertTriangle className="w-3 h-3 text-[#ff6b57]" />
                  <span>解除拦截指引与一键重检</span>
                </button>
              )}
            </>
          )}
        </div>
        <div>
          {capability.isQuark || !capability.hasNotification
            ? '夸克模式状态：'
            : capability.hasPushManager
            ? '锁屏离线推送：'
            : '系统通知机制：'}
          <b className="text-[#4ade80]">
            {capability.isQuark || !capability.hasNotification
              ? (settings.inapp ? '应用内强提醒 + 物理震动已开启 ✓' : '已就绪 (点击开启)')
              : capability.hasPushManager
              ? (isPushSubscribed ? `已激活 ✓ (当前账号已绑定 ${serverDeviceCount} 台设备)` : '未开启')
              : (localSysPermission === 'granted' ? '本地增强系统通知已就绪 ✓' : '本地模式 (待授权)')}
          </b>
          {' ｜ '}作业截止临期：<b className="text-[#6b7cff]">24h / 3h 自动预警</b>
        </div>
        <div>
          明日早课情况：
          {tomorrowFirstCourse ? (
            <b className="text-[#e9e4d8]">
              {nextDay.isMonday ? '【周一开课】' : '明天'}{tomorrowFirstCourse.name} ({SLOTS[tomorrowFirstCourse.s].s} 首节 ｜ @{tomorrowFirstCourse.room || '待定'})
            </b>
          ) : (
            <span className="text-[#8f8b80]">明天暂无课程安排</span>
          )}
        </div>
      </div>

      {/* Featured Feature: Sunday Evening & Next Day Class Preview */}
      <div className="bg-gradient-to-r from-[#1c223a] to-[#1a1c22] border-2 border-[#6b7cff] p-4 rounded-lg shadow-lg text-[#e9e4d8] space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Moon className="w-4 h-4 text-[#6b7cff]" />
            <h4 className="font-editorial font-bold text-base text-[#e9e4d8]">
              周日晚间备课提醒与课表提前更新
            </h4>
          </div>
          <span className="text-[10px] px-2 py-0.5 rounded bg-[#6b7cff]/20 text-[#8ea4ff] font-bold">
            PRO
          </span>
        </div>

        <p className="text-xs text-[#a8a399] leading-relaxed">
          每到周日晚上，自动检查新一周（周一早晨）是否有课并准时提醒，同时将课程表和小组件<strong>提前切换到新一周</strong>，让你睡前从容掌握明早行程与教室！
        </p>

        <div className="border-t border-[#333644] pt-2.5 divide-y divide-[#2a2d36] text-xs">
          {/* Sunday Eve Alert Toggle */}
          <div
            onClick={() => onUpdateSettings({ sundayEveEnabled: !settings.sundayEveEnabled })}
            className="flex items-center justify-between py-2 cursor-pointer hover:bg-white/[0.02]"
          >
            <div>
              <div className="font-bold text-[#e9e4d8] flex items-center gap-1.5">
                <Bell className="w-3.5 h-3.5 text-[#6b7cff]" />
                <span>周日晚间提醒明天周一有课</span>
              </div>
              <div className="text-[11px] text-[#8f8b80] mt-0.5">
                在周日晚向你推送周一早课名称、时间、教室与总课程数
              </div>
            </div>
            <span
              className={`text-xs font-bold px-2 py-0.5 rounded ${
                settings.sundayEveEnabled
                  ? 'bg-[#4ade80] text-[#1d1f24]'
                  : 'border border-[#8f8b80] text-[#8f8b80]'
              }`}
            >
              {settings.sundayEveEnabled ? '开' : '关'}
            </span>
          </div>

          {/* Sunday Eve Alert Hour Selector */}
          {settings.sundayEveEnabled && (
            <div className="py-2.5 space-y-1.5">
              <div className="text-[11px] text-[#8f8b80] font-mono">周日晚提醒时间点：</div>
              <div className="grid grid-cols-5 border border-[#333644] divide-x divide-[#333644] text-xs font-bold rounded overflow-hidden">
                {[19, 20, 21, 22].map(hour => (
                  <button
                    key={hour}
                    type="button"
                    onClick={() => {
                      onUpdateSettings({ sundayEveHour: hour });
                      toast(`已设为周日晚 ${hour}:00 提醒`);
                    }}
                    className={`py-1.5 transition-colors cursor-pointer ${
                      (settings.sundayEveHour || 20) === hour
                        ? 'bg-[#6b7cff] text-white'
                        : 'bg-[#181a20] text-[#a8a399] hover:text-white'
                    }`}
                  >
                    {hour}:00
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => {
                    onUpdateSettings({ sundayEveHour: 21 });
                    toast('已设为周日晚 21:30 提醒');
                  }}
                  className={`py-1.5 transition-colors cursor-pointer ${
                    (settings.sundayEveHour || 20) === 21
                      ? 'bg-[#6b7cff] text-white'
                      : 'bg-[#181a20] text-[#a8a399] hover:text-white'
                  }`}
                >
                  21:30
                </button>
              </div>
            </div>
          )}

          {/* Sunday Auto Advance Timetable Toggle */}
          <div
            onClick={() => onUpdateSettings({ sundayAutoAdvance: !settings.sundayAutoAdvance })}
            className="flex items-center justify-between py-2 cursor-pointer hover:bg-white/[0.02]"
          >
            <div>
              <div className="font-bold text-[#e9e4d8] flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-[#6b7cff]" />
                <span>周日晚间课表自动提前更新</span>
              </div>
              <div className="text-[11px] text-[#8f8b80] mt-0.5">
                周日 18:00 后课程表与小组件自动切换到新一周第 {currentWeek + 1} 周
              </div>
            </div>
            <span
              className={`text-xs font-bold px-2 py-0.5 rounded ${
                settings.sundayAutoAdvance
                  ? 'bg-[#6b7cff] text-white'
                  : 'border border-[#8f8b80] text-[#8f8b80]'
              }`}
            >
              {settings.sundayAutoAdvance ? '开' : '关'}
            </span>
          </div>

          {/* Every Eve Preview */}
          <div
            onClick={() => onUpdateSettings({ everyEvePreview: !settings.everyEvePreview })}
            className="flex items-center justify-between py-2 cursor-pointer hover:bg-white/[0.02]"
          >
            <div>
              <div className="font-bold text-[#e9e4d8] flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#d99a2b]" />
                <span>每日晚间早课预告</span>
              </div>
              <div className="text-[11px] text-[#8f8b80] mt-0.5">
                周一至周六晚间 21:00 也同样弹窗预报次日首节课程
              </div>
            </div>
            <span
              className={`text-xs font-bold px-2 py-0.5 rounded ${
                settings.everyEvePreview
                  ? 'bg-[#d99a2b] text-[#1d1f24]'
                  : 'border border-[#8f8b80] text-[#8f8b80]'
              }`}
            >
              {settings.everyEvePreview ? '开' : '关'}
            </span>
          </div>
        </div>
      </div>

      {/* Push / Local System Notification Card */}
      {capability.hasPushManager ? (
        <div className="bg-[#1f222a] border-2 border-[#4ade80]/60 p-4 rounded-lg shadow-lg text-[#e9e4d8] space-y-3.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Radio className="w-4 h-4 text-[#4ade80]" />
              <h4 className="font-editorial font-bold text-base text-[#e9e4d8]">
                锁屏与系统级 Web Push 离线推送
              </h4>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded bg-[#4ade80]/20 text-[#4ade80] font-bold">
              锁屏即达
            </span>
          </div>

          <p className="text-xs text-[#a8a399] leading-relaxed">
            采用标准 W3C Web Push 规范。<strong>无需打开网页或保持手机亮屏</strong>，即使手机黑屏休眠或切至后台，云端定时器也会在<strong>课前 15 分钟与作业截止前</strong>自动唤醒手机通知中心并震动提醒！
          </p>

          {/* Status indicator row */}
          <div className="bg-[#16181d] border border-[#2e313b] p-3 rounded text-xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[#8f8b80]">当前浏览器支持：</span>
              <span className="text-[#4ade80] font-medium">支持 Web Push 云唤醒 ✓</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#8f8b80]">当前设备推送状态：</span>
              <span className={isPushSubscribed ? 'text-[#4ade80] font-bold' : 'text-[#8f8b80]'}>
                {isPushSubscribed ? '已在此设备激活 ✓' : '未开启本设备推送'}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#8f8b80]">账号绑定接收设备数：</span>
              <span className="text-[#e9e4d8] font-mono font-medium">
                {serverDeviceCount} 台设备在线接收
              </span>
            </div>
          </div>

          {/* Blocked Permission Alert Banner */}
          {notificationPermission === 'denied' && (
            <div className="bg-[#ff6b57]/15 border border-[#ff6b57]/50 p-3 rounded-lg text-xs space-y-2">
              <div className="flex items-center gap-2 text-[#ff8f80] font-bold">
                <AlertTriangle className="w-4 h-4 shrink-0 text-[#ff6b57]" />
                <span>通知已被手机浏览器拦截，暂时无法接收锁屏通知</span>
              </div>
              <p className="text-[11px] text-[#a8a399] leading-relaxed">
                手机浏览器曾记录过禁止通知。点击下方指引仅需 10 秒即可在浏览器设置中一键解除！
              </p>
              <button
                type="button"
                onClick={() => setShowUnblockGuide(true)}
                className="w-full py-2 bg-[#ff6b57] hover:bg-[#e05643] text-white font-bold text-xs rounded transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-[#ff6b57]/20"
              >
                <span>查看解除指引并一键重新检测</span>
              </button>
            </div>
          )}

          {/* Toggle & Test Actions */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
            <button
              type="button"
              disabled={pushLoading}
              onClick={handleTogglePush}
              className={`py-2.5 px-3 rounded text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                isPushSubscribed
                  ? 'bg-[#2a2d36] text-[#e9e4d8] border border-[#4ade80]/40 hover:bg-[#323642]'
                  : 'bg-[#4ade80] text-[#1d1f24] hover:bg-[#3ec972] shadow-md shadow-[#4ade80]/20'
              }`}
            >
              {pushLoading ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              ) : isPushSubscribed ? (
                <CheckCircle className="w-3.5 h-3.5 text-[#4ade80]" />
              ) : (
                <Bell className="w-3.5 h-3.5" />
              )}
              <span>
                {pushLoading ? '处理中...' : isPushSubscribed ? '已开启锁屏推送 (点击注销)' : '开启锁屏系统推送'}
              </span>
            </button>

            <button
              type="button"
              disabled={testingPush || !isPushSubscribed}
              onClick={handleTestServerPush}
              className={`py-2.5 px-3 rounded text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer border ${
                isPushSubscribed
                  ? 'bg-[#262832] border-[#6b7cff] text-[#6b7cff] hover:bg-[#6b7cff] hover:text-white'
                  : 'bg-[#1b1c22] border-[#33363d] text-[#62605b] cursor-not-allowed'
              }`}
            >
              {testingPush ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Smartphone className="w-3.5 h-3.5" />
              )}
              <span>{testingPush ? '发送测试推送中...' : '发送锁屏测试通知 (可熄屏验证)'}</span>
            </button>
          </div>

          <div className="text-[11px] text-[#78746c] leading-relaxed border-t border-[#2e313b] pt-2">
            💡 锁屏提醒说明：点击“开启锁屏系统推送”授权后，即使手机锁屏放入书包，云端也会在开课前 15 分钟及作业临期 24h / 3h 准时推送；iOS 用户需先在 Safari 中“添加到主屏幕”开启系统通知。
          </div>
        </div>
      ) : capability.isQuark || capability.mode === 'quark_inapp' || !capability.hasNotification || capability.isForceFallback ? (
        <div className="bg-[#1f222a] border-2 border-[#d99a2b]/70 p-4 rounded-lg shadow-lg text-[#e9e4d8] space-y-3.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Smartphone className="w-4 h-4 text-[#d99a2b]" />
              <h4 className="font-editorial font-bold text-base text-[#e9e4d8]">
                {capability.isForceFallback
                  ? '强制开启 · 通知全效组合降级保底模式'
                  : capability.isQuark
                  ? '夸克浏览器 · 应用内悬浮横幅与物理震动模式'
                  : '通知全效组合降级保底模式 (悬浮横幅 + 震动 + 声音)'}
              </h4>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded bg-[#d99a2b]/20 text-[#d99a2b] font-bold">
              {capability.isForceFallback ? '强制降级保底' : '组合降级保底模式'}
            </span>
          </div>

          <p className="text-xs text-[#a8a399] leading-relaxed">
            {capability.isQuark
              ? '检测到当前使用夸克浏览器（已禁原生通知）。本系统已为您自动无缝激活【应用内强提醒卡片 + 手机物理震动 + 课前清脆提示音】！无论在应用内任何界面，课前均会触发物理震动与弹窗提醒。'
              : '针对 Edge、华为浏览器或系统拦截通知环境，系统已为您自动激活【应用内强提醒悬浮横幅 + 手机物理马达震动 + Web Audio 提示音】！并支持一键导入手机系统日历响铃。'}
          </p>

          {/* Status indicator row */}
          <div className="bg-[#16181d] border border-[#2e313b] p-3 rounded text-xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[#8f8b80]">组合降级就绪状态：</span>
              <span className="text-[#4ade80] font-medium">横幅 + 震动 + 提示音已激活 ✓</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#8f8b80]">课前手机物理震动：</span>
              <span className="text-[#4ade80] font-bold">
                {typeof navigator !== 'undefined' && 'vibrate' in navigator ? '支持物理震动 (Vibrate) ✓' : '提示音模式 ✓'}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#8f8b80]">课前悬浮提醒卡片：</span>
              <span className="text-[#6b7cff] font-medium">
                {settings.inapp ? '应用内横幅已开启 ✓' : '已就绪 (点击下方开启)'}
              </span>
            </div>
          </div>

          {/* Actions */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
            <button
              type="button"
              onClick={() => {
                onUpdateSettings({ inapp: true, sound: true, enabled: true });
                if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
                  try { navigator.vibrate([250, 100, 250]); } catch {}
                }
                toast('全效降级提醒模式已开启！已同步激活页面横幅、手机震动与蜂鸣提示音。');
              }}
              className="py-2.5 px-3 rounded text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer bg-[#d99a2b] text-[#1d1f24] hover:bg-[#c4871f] shadow-md shadow-[#d99a2b]/20"
            >
              <CheckCircle className="w-3.5 h-3.5" />
              <span>一键激活全效组合降级提醒</span>
            </button>

            <button
              type="button"
              onClick={() => {
                onTriggerTestReminder();
                if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
                  try { navigator.vibrate([300, 150, 300, 150, 400]); } catch {}
                }
                toast('【组合降级测试成功】已触发物理震动、悬浮横幅与提示音！');
              }}
              className="py-2.5 px-3 rounded text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer border bg-[#262832] border-[#d99a2b] text-[#d99a2b] hover:bg-[#d99a2b] hover:text-[#1d1f24]"
            >
              <Play className="w-3.5 h-3.5" />
              <span>测试组合降级 (横幅+震动+声音)</span>
            </button>
          </div>

          {/* Native Browser Switch Tip for Lock-screen */}
          <div className="border-t border-[#2e313b] pt-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="text-[11px] text-[#8f8b80]">
              💡 遇到手机锁屏黑屏拦截？推荐导出手机系统日历或开启诊断：
            </div>
            <div className="flex items-center gap-2">
              {onOpenDoctor && (
                <button
                  type="button"
                  onClick={onOpenDoctor}
                  className="text-[11px] text-[#8f8b80] hover:text-[#e9e4d8] font-bold flex items-center gap-1 cursor-pointer bg-[#242732] px-2 py-1 rounded border border-[#3e4254] shrink-0"
                >
                  <Globe className="w-3 h-3 text-[#6b7cff]" />
                  <span>内核诊断</span>
                </button>
              )}
              <button
                type="button"
                onClick={handleCopyUrlForNativeBrowser}
                className="text-[11px] text-[#6b7cff] hover:text-[#8ea4ff] font-bold flex items-center gap-1 cursor-pointer bg-[#6b7cff]/15 px-2.5 py-1 rounded border border-[#6b7cff]/30 w-fit shrink-0"
              >
                <span>复制网址 / 打开排查向导</span>
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-[#1f222a] border-2 border-[#6b7cff]/60 p-4 rounded-lg shadow-lg text-[#e9e4d8] space-y-3.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Smartphone className="w-4 h-4 text-[#6b7cff]" />
              <h4 className="font-editorial font-bold text-base text-[#e9e4d8]">
                {capability.isHuaweiOrDomestic ? '华为/鸿蒙设备 · 本地增强系统级通知' : '本地增强系统级通知模式'}
              </h4>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded bg-[#6b7cff]/20 text-[#8ea4ff] font-bold">
              本地系统通知
            </span>
          </div>

          <p className="text-xs text-[#a8a399] leading-relaxed">
            检测到当前环境为{capability.isHuaweiOrDomestic ? '华为浏览器 / 鸿蒙系统' : '移动端环境'}（系统未内置 Google FCM 远端中继）。本应用已为您自动无缝切换为<strong>「本地增强系统级通知与后台守护模式」</strong>！结合手机后台自启动权限，课前与作业临期仍可在手机通知栏准时弹出横幅！
          </p>

          {/* Status indicator row */}
          <div className="bg-[#16181d] border border-[#2e313b] p-3 rounded text-xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[#8f8b80]">系统通知能力支持：</span>
              <span className={capability.hasNotification ? 'text-[#4ade80] font-medium' : 'text-[#ff6b57] font-medium'}>
                {capability.hasNotification ? '支持本地原生系统通知 ✓' : '暂不支持（需允许通知权限）'}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#8f8b80]">系统通知权限状态：</span>
              <span className={localSysPermission === 'granted' ? 'text-[#4ade80] font-bold' : 'text-[#ff6b57] font-bold'}>
                {localSysPermission === 'granted' ? '已授权允许 ✓' : '未授权 (请点击下方开启)'}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#8f8b80]">通知提醒机制：</span>
              <span className="text-[#6b7cff] font-medium">
                本地 Notification + Service Worker 保活
              </span>
            </div>
          </div>

          {/* Blocked Permission Alert Banner */}
          {(localSysPermission === 'denied' || notificationPermission === 'denied') && (
            <div className="bg-[#ff6b57]/15 border border-[#ff6b57]/50 p-3 rounded-lg text-xs space-y-2">
              <div className="flex items-center gap-2 text-[#ff8f80] font-bold">
                <AlertTriangle className="w-4 h-4 shrink-0 text-[#ff6b57]" />
                <span>手机浏览器已拦截系统通知权限</span>
              </div>
              <p className="text-[11px] text-[#a8a399] leading-relaxed">
                当前通知权限已被设为禁止。请按照图文指引将通知权限切换为“允许”后重新检测！
              </p>
              <button
                type="button"
                onClick={() => setShowUnblockGuide(true)}
                className="w-full py-2 bg-[#ff6b57] hover:bg-[#e05643] text-white font-bold text-xs rounded transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-[#ff6b57]/20"
              >
                <span>查看解除指引并一键重新检测</span>
              </button>
            </div>
          )}

          {/* Actions */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
            <button
              type="button"
              onClick={handleRequestLocalPermission}
              className={`py-2.5 px-3 rounded text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                localSysPermission === 'granted'
                  ? 'bg-[#2a2d36] text-[#e9e4d8] border border-[#4ade80]/40 hover:bg-[#323642]'
                  : 'bg-[#6b7cff] text-white hover:bg-[#5b6cee] shadow-md shadow-[#6b7cff]/20'
              }`}
            >
              {localSysPermission === 'granted' ? (
                <CheckCircle className="w-3.5 h-3.5 text-[#4ade80]" />
              ) : (
                <Bell className="w-3.5 h-3.5" />
              )}
              <span>
                {localSysPermission === 'granted' ? '系统通知已开启 ✓ (重新检测)' : '开启系统通知权限'}
              </span>
            </button>

            <button
              type="button"
              onClick={handleTestLocalNotification}
              className="py-2.5 px-3 rounded text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer border bg-[#262832] border-[#6b7cff] text-[#6b7cff] hover:bg-[#6b7cff] hover:text-white"
            >
              <Play className="w-3.5 h-3.5" />
              <span>测试发送本地系统通知</span>
            </button>
          </div>

          {/* Keepalive Guide Trigger */}
          <div className="border-t border-[#2e313b] pt-2.5 flex items-center justify-between">
            <div className="text-[11px] text-[#8f8b80]">
              💡 手机熄屏后若想准时接收通知，需配置后台保活：
            </div>
            <button
              type="button"
              onClick={() => setShowHuaweiGuide(true)}
              className="text-[11px] text-[#6b7cff] hover:text-[#8ea4ff] font-bold underline cursor-pointer shrink-0 ml-2"
            >
              查看华为/鸿蒙保活指引 →
            </button>
          </div>
        </div>
      )}

      {/* Lead Time Selection */}
      <div>
        <div className="text-[10px] font-bold tracking-[3px] text-[#8f8b80] mb-2 font-mono">
          LEAD · 课前即时提醒时间
        </div>
        <div className="grid grid-cols-4 border border-[#e9e4d8] text-xs font-bold divide-x divide-[#e9e4d8]">
          {([5, 10, 15, 20] as const).map(lead => (
            <button
              key={lead}
              onClick={() => {
                onUpdateSettings({ lead });
                toast(`已设为课前 ${lead} 分钟提醒`);
              }}
              className={`py-2 text-center transition-colors cursor-pointer ${
                settings.lead === lead
                  ? 'bg-[#e9e4d8] text-[#1d1f24]'
                  : 'text-[#e9e4d8] hover:bg-white/10'
              }`}
            >
              提前 {lead} 分
            </button>
          ))}
        </div>
      </div>

      {/* Channels List */}
      <div>
        <div className="text-[10px] font-bold tracking-[3px] text-[#8f8b80] mb-2 font-mono">
          CHANNEL · 提醒通道设置
        </div>
        <div className="border-t-2 border-[#e9e4d8] divide-y divide-[#2a2d34] text-sm">
          {/* In-app */}
          <div
            onClick={() => onUpdateSettings({ inapp: !settings.inapp })}
            className="flex items-center justify-between py-3.5 cursor-pointer hover:bg-white/[0.03] transition-colors"
          >
            <div>
              <div className="font-semibold text-[#e9e4d8] flex items-center gap-2">
                <Bell className="w-4 h-4 text-[#6b7cff]" />
                应用内提醒卡片
              </div>
              <div className="text-xs text-[#8f8b80] mt-0.5">
                页面内弹出醒目提醒卡片（含教室、倒计时与快速进入）
              </div>
            </div>
            <span
              className={`text-xs font-bold px-2.5 py-0.5 rounded ${
                settings.inapp
                  ? 'bg-[#6b7cff] text-white'
                  : 'border border-[#8f8b80] text-[#8f8b80]'
              }`}
            >
              {settings.inapp ? '开' : '关'}
            </span>
          </div>

          {/* System Notification */}
          <div
            onClick={() => {
              if (!settings.sys && notificationPermission !== 'granted') {
                requestSysPermission();
              } else {
                onUpdateSettings({ sys: !settings.sys });
              }
            }}
            className="flex items-center justify-between py-3.5 cursor-pointer hover:bg-white/[0.03] transition-colors"
          >
            <div>
              <div className="font-semibold text-[#e9e4d8] flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#4ade80]" />
                系统级桌面/横幅通知
              </div>
              <div className="text-xs text-[#8f8b80] mt-0.5">
                锁屏或在后台时向系统通知中心推送消息
              </div>
            </div>
            <span
              className={`text-xs font-bold px-2.5 py-0.5 rounded ${
                settings.sys && notificationPermission === 'granted'
                  ? 'bg-[#4ade80] text-[#1d1f24]'
                  : 'border border-[#8f8b80] text-[#8f8b80]'
              }`}
            >
              {settings.sys && notificationPermission === 'granted' ? '开' : '关'}
            </span>
          </div>

          {/* Audio Beep */}
          <div
            onClick={() => onUpdateSettings({ sound: !settings.sound })}
            className="flex items-center justify-between py-3.5 cursor-pointer hover:bg-white/[0.03] transition-colors"
          >
            <div>
              <div className="font-semibold text-[#e9e4d8] flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-[#d99a2b]" />
                提醒提示音
              </div>
              <div className="text-xs text-[#8f8b80] mt-0.5">
                课前触发一声清脆正弦波短蜂鸣（零网络依赖）
              </div>
            </div>
            <span
              className={`text-xs font-bold px-2.5 py-0.5 rounded ${
                settings.sound
                  ? 'bg-[#d99a2b] text-[#1d1f24]'
                  : 'border border-[#8f8b80] text-[#8f8b80]'
              }`}
            >
              {settings.sound ? '开' : '关'}
            </span>
          </div>

          {/* Master Toggle */}
          <div
            onClick={() => onUpdateSettings({ enabled: !settings.enabled })}
            className="flex items-center justify-between py-3.5 cursor-pointer hover:bg-white/[0.03] transition-colors"
          >
            <div>
              <div className="font-semibold text-[#e9e4d8]">总开关 · 启用提醒</div>
              <div className="text-xs text-[#8f8b80] mt-0.5">一键控制全部课前提醒行为</div>
            </div>
            <span
              className={`text-xs font-bold px-2.5 py-0.5 rounded ${
                settings.enabled
                  ? 'bg-[#e9e4d8] text-[#1d1f24]'
                  : 'border border-[#8f8b80] text-[#8f8b80]'
              }`}
            >
              {settings.enabled ? '开' : '关'}
            </span>
          </div>
        </div>
      </div>

      {/* Test Buttons Area */}
      <div className="space-y-2 pt-1">
        <button
          type="button"
          onClick={onTriggerSundayTestReminder || onTriggerTestReminder}
          className="w-full py-3 bg-[#6b7cff] hover:bg-[#5b6cee] text-white font-bold text-xs tracking-widest flex items-center justify-center gap-2 transition-colors cursor-pointer rounded shadow-md"
        >
          <Moon className="w-4 h-4" />
          <span>立即测试【周日晚间提醒明天有课】弹窗与通知</span>
        </button>

        <button
          type="button"
          onClick={onTriggerTestReminder}
          className="w-full py-2.5 bg-[#252832] hover:bg-[#2e323e] border border-[#3e4252] text-[#e9e4d8] font-semibold text-xs tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer rounded"
        >
          <Play className="w-3.5 h-3.5 fill-current text-[#8f8b80]" />
          <span>测试课前 10 分钟即时提醒卡片</span>
        </button>
      </div>

      {/* Note */}
      <div className="p-3 border-l-2 border-[#8f8b80] bg-[#1a1c21] text-xs text-[#8f8b80] leading-relaxed">
        提示：周日晚间提醒将在周日晚 20:00 准时通过应用内弹窗、系统通知中心及蜂鸣声播报周一早晨课程；同时课程表将在周日晚 18:00 自动为您提前载入新一周课表。
      </div>

      {/* Huawei Keepalive Guide Modal */}
      {showHuaweiGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm animate-fade-in">
          <div className="bg-[#1f222a] border-2 border-[#6b7cff] rounded-xl max-w-md w-full p-5 space-y-4 shadow-2xl text-[#e9e4d8]">
            <div className="flex items-center justify-between border-b border-[#333644] pb-3">
              <div className="flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-[#6b7cff]" />
                <h3 className="font-editorial font-bold text-lg text-[#e9e4d8]">
                  华为 / 鸿蒙手机后台保活指引
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowHuaweiGuide(false)}
                className="text-[#8f8b80] hover:text-white text-lg font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="text-xs text-[#a8a399] leading-relaxed space-y-3">
              <div className="bg-[#16181d] p-3 rounded border border-[#2e313b] space-y-1">
                <div className="font-bold text-[#e9e4d8] flex items-center gap-1.5">
                  <span className="w-4 h-4 rounded-full bg-[#6b7cff] text-white text-[10px] flex items-center justify-center">1</span>
                  <span>开启“应用启动管理”后台常驻</span>
                </div>
                <p className="text-[11px] text-[#8f8b80] pl-5">
                  打开手机【设置】 ➔ 【应用和服务】 ➔ 【应用启动管理】 ➔ 找到“华为浏览器”或“掌上课表” ➔ 关闭“自动管理”，切换为<strong>【手动管理】</strong>，勾选“允许自启动”、“允许关联启动”和<strong>“允许后台活动”</strong>。
                </p>
              </div>

              <div className="bg-[#16181d] p-3 rounded border border-[#2e313b] space-y-1">
                <div className="font-bold text-[#e9e4d8] flex items-center gap-1.5">
                  <span className="w-4 h-4 rounded-full bg-[#6b7cff] text-white text-[10px] flex items-center justify-center">2</span>
                  <span>多任务卡片锁定</span>
                </div>
                <p className="text-[11px] text-[#8f8b80] pl-5">
                  从手机屏幕底部轻轻上滑进入后台多任务界面，在“华为浏览器”或“掌上课表”卡片上<strong>向下拉动</strong>，卡片上方出现小锁🔒标记，防止被系统一键清理。
                </p>
              </div>

              <div className="bg-[#16181d] p-3 rounded border border-[#2e313b] space-y-1">
                <div className="font-bold text-[#e9e4d8] flex items-center gap-1.5">
                  <span className="w-4 h-4 rounded-full bg-[#4ade80] text-[#1d1f24] text-[10px] flex items-center justify-center">3</span>
                  <span>推荐：添加到桌面快捷方式</span>
                </div>
                <p className="text-[11px] text-[#8f8b80] pl-5">
                  在华为浏览器底部点击“菜单 (三道杠)” ➔ 选择<strong>“添加到桌面”</strong>，之后像 App 一样直接从桌面图标点开，拥有更加稳定常驻的系统通知与独立后台通道。
                </p>
              </div>

              <div className="text-[10.5px] text-[#78746c] italic pt-1">
                * 补充说明：如您需要绝对零后台、关机/纯休眠状态下的云端中继推送，也可在华为应用市场安装使用 Edge 或 Chrome 手机版访问本系统。
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowHuaweiGuide(false)}
              className="w-full py-2.5 bg-[#6b7cff] hover:bg-[#5b6cee] text-white font-bold text-xs rounded transition-colors cursor-pointer"
            >
              我知道了
            </button>
          </div>
        </div>
      )}

      {/* Browser Notification Unblock Guide Modal */}
      <NotificationGuideModal
        isOpen={showUnblockGuide}
        onClose={() => setShowUnblockGuide(false)}
        onPermissionGranted={handlePermissionRecovered}
        toast={toast}
      />
    </div>
  );
};
